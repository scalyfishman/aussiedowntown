Created by ATomIK - www.ATomIK.info

===================================

Installation:

1. Drag and drop these files into a directory on your webhost.
2. Navigate to it in your browser.
3. It may ask you to change the "config/" folder's permissions to 777 recursively.
 - If you're not sure how to do this there is a screenshot from FilaZilla displayed on the webpage!
4. Leave a review:

https://scriptfodder.com/scripts/view/1157/reviews

===================================

Thanks for supporting my side development project!

You can download custom background webm videos here:

http://atomik.info/downloads