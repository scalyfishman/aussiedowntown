<?php require 'inc/core.php';
